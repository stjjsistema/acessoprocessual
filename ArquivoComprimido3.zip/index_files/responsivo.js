function quandoAlteraLarguraUtilJanelaNavegadorPara320FuncaoLocal() {
	if(!document.getElementById('idSelectTipoPesquisaFormulario')){
		setDisplay('idDivFoneticaBloco', 'inline-block'); redefineLargura('idDivFoneticaBloco', '90%');		
		setDisplay('idFormularioExtendidoBlocoNumeroColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoNumeroColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoOab', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOab', '95%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna2', '95%');
		setBackgroundColor('idFormularioExtendidoBlocoJulgador', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoOrigem', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoTipo', '#EFF6FB');
		setBackgroundColor('idDivFoneticaBloco', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoCodigoNumero', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoCodigoNumero', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoNome', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoNome', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoOpcoes', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoOpcoes', '#EFF6FB');
	}
	setFloat('idFormularioExtendidoParteAdvogado', 'none');
	setDisplay('idFormularioExtendidoParteAdvogado', 'block');
	setBackgroundColor('idDivLinhaFormulario', '#FFF');//setBackgroundColor('idDivLinhaFormulario', '#EFF6FB');
	setBackgroundColor('idDivBlocoFormularioExtendido', '#FFF');//setBackgroundColor('idDivBlocoFormularioExtendido', '#EFF6FB');
	setBackgroundColor('idFormularioOpcoesBloco', '#FFF');//setBackgroundColor('idFormularioOpcoesBloco', '#EFF6FB');
}
function quandoAlteraLarguraUtilJanelaNavegadorPara480FuncaoLocal() {
	if(!document.getElementById('idSelectTipoPesquisaFormulario')){
		setDisplay('idDivFoneticaBloco', 'inline-block'); redefineLargura('idDivFoneticaBloco', '90%');		
		setDisplay('idFormularioExtendidoBlocoNumeroColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoNumeroColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoOab', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOab', '95%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna2', '95%');
		setBackgroundColor('idFormularioExtendidoBlocoJulgador', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoOrigem', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoTipo', '#EFF6FB');
		setBackgroundColor('idDivFoneticaBloco', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoCodigoNumero', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoCodigoNumero', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoNome', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoNome', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoOpcoes', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoOpcoes', '#EFF6FB');
	}
	setFloat('idFormularioExtendidoParteAdvogado', 'none');
	setDisplay('idFormularioExtendidoParteAdvogado', 'block');
	setBackgroundColor('idDivLinhaFormulario', '#FFF');//setBackgroundColor('idDivLinhaFormulario', '#EFF6FB');
	setBackgroundColor('idDivBlocoFormularioExtendido', '#FFF');//setBackgroundColor('idDivBlocoFormularioExtendido', '#EFF6FB');
	setBackgroundColor('idFormularioOpcoesBloco', '#FFF');//setBackgroundColor('idFormularioOpcoesBloco', '#EFF6FB');
}
function quandoAlteraLarguraUtilJanelaNavegadorPara600FuncaoLocal() {
	if(!document.getElementById('idSelectTipoPesquisaFormulario')){
		setDisplay('idDivFoneticaBloco', 'inline-block'); redefineLargura('idDivFoneticaBloco', '90%');
		setDisplay('idFormularioExtendidoBlocoNumeroColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoNumeroColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoOab', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOab', '95%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna2', '95%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna1', '95%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna2', '95%');
		setBackgroundColor('idFormularioExtendidoBlocoJulgador', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoOrigem', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoTipo', '#EFF6FB');
		setBackgroundColor('idDivFoneticaBloco', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoCodigoNumero', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoCodigoNumero', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoNome', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoNome', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoOpcoes', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoOpcoes', '#EFF6FB');
	}
	setFloat('idFormularioExtendidoParteAdvogado', 'none');
	setDisplay('idFormularioExtendidoParteAdvogado', 'block');
	setBackgroundColor('idDivLinhaFormulario', '#FFF');//setBackgroundColor('idDivLinhaFormulario', '#EFF6FB');
	setBackgroundColor('idDivBlocoFormularioExtendido', '#FFF');//setBackgroundColor('idDivBlocoFormularioExtendido', '#EFF6FB');
	setBackgroundColor('idFormularioOpcoesBloco', '#FFF');//setBackgroundColor('idFormularioOpcoesBloco', '#EFF6FB');
}
function quandoAlteraLarguraUtilJanelaNavegadorPara760FuncaoLocal() {
	if(!document.getElementById('idSelectTipoPesquisaFormulario')){
		setDisplay('idDivFoneticaBloco', 'inline-block'); redefineLargura('idDivFoneticaBloco', '42%');
		setDisplay('idFormularioExtendidoBlocoNumeroColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna1', '45%');
		setDisplay('idFormularioExtendidoBlocoNumeroColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna2', '45%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna1', '45%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna2', '45%');
		setDisplay('idFormularioExtendidoBlocoOab', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOab', '95%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna1', '45%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna2', '45%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna1', '60.5%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna2', '37.5%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna1', '45%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna2', '45%');
		setBackgroundColor('idFormularioExtendidoBlocoJulgador', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoOrigem', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoTipo', '#EFF6FB');
		setBackgroundColor('idDivFoneticaBloco', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoCodigoNumero', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoCodigoNumero', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoNome', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoNome', '#EFF6FB');
		setBackgroundColor('idFormularioExtendidoBlocoOpcoes', '#FFF');//setBackgroundColor('idFormularioExtendidoBlocoOpcoes', '#EFF6FB');
	}
	setFloat('idFormularioExtendidoParteAdvogado', 'left');
	setDisplay('idFormularioExtendidoParteAdvogado', 'inline-table');
	setBackgroundColor('idDivLinhaFormulario', '#FFF');//setBackgroundColor('idDivLinhaFormulario', '#EFF6FB');
	setBackgroundColor('idDivBlocoFormularioExtendido', '#FFF');//setBackgroundColor('idDivBlocoFormularioExtendido', '#EFF6FB');
	setBackgroundColor('idFormularioOpcoesBloco', '#FFF');//setBackgroundColor('idFormularioOpcoesBloco', '#EFF6FB');
}
function quandoAlteraLarguraUtilJanelaNavegadorPara900FuncaoLocal() {
	if(!document.getElementById('idSelectTipoPesquisaFormulario')){		
		setDisplay('idDivFoneticaBloco', 'inline-block'); redefineLargura('idDivFoneticaBloco', '42%');
		setDisplay('idFormularioExtendidoBlocoNumeroColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna1', '45%');
		setDisplay('idFormularioExtendidoBlocoNumeroColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNumeroColuna2', '45%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna1', '45%');
		setDisplay('idFormularioExtendidoBlocoNomeColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoNomeColuna2', '45%');
		setDisplay('idFormularioExtendidoBlocoOab', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOab', '95%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna1', '45%');
		setDisplay('idFormularioExtendidoBlocoJulgadorColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoJulgadorColuna2', '45%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna1', '60.5%');
		setDisplay('idFormularioExtendidoBlocoOrigemColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoOrigemColuna2', '37.5%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna1', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna1', '45%');
		setDisplay('idFormularioExtendidoBlocoTipoColuna2', 'inline-block'); redefineLargura('idFormularioExtendidoBlocoTipoColuna2', '45%');
		setBackgroundColor('idFormularioExtendidoBlocoJulgador', 'white');
		setBackgroundColor('idFormularioExtendidoBlocoOrigem', 'white');
		setBackgroundColor('idFormularioExtendidoBlocoTipo', 'white');
		setBackgroundColor('idDivFoneticaBloco', 'white');
		setBackgroundColor('idFormularioExtendidoBlocoCodigoNumero', 'white');
		setBackgroundColor('idFormularioExtendidoBlocoNome', 'white');
		setBackgroundColor('idFormularioExtendidoBlocoOpcoes', 'white');
	}
	setFloat('idFormularioExtendidoParteAdvogado', 'left');
	setDisplay('idFormularioExtendidoParteAdvogado', 'inline-table');
	setBackgroundColor('idDivLinhaFormulario', 'white');
	setBackgroundColor('idDivBlocoFormularioExtendido', 'white');
	setBackgroundColor('idFormularioOpcoesBloco', 'white');
}